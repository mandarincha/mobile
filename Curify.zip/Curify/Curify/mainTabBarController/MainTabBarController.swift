//
//  ViewController.swift
//  Curify
//
//

import UIKit

class MainTabBarController: UITabBarController {

    let nc1 = UINavigationController(rootViewController: HomeViewController())
    let nc2 = UINavigationController(rootViewController: DoctorsViewController())
    let nc3 = UINavigationController(rootViewController: CurifyChatViewController())
    let nc4 = UINavigationController(rootViewController: DrugsViewController())
    let nc5 = UINavigationController(rootViewController: ProfileViewController())
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initViews()
        setTitles()
        setTabBarItemImages()
        
        setViewControllers([nc1, nc2, nc3, nc4, nc5], animated: true)
    }
    
    private func initViews() {
        tabBar.tintColor = Colors.label
        tabBar.unselectedItemTintColor = .systemGray
    }
    
    private func setTitles() {
        nc1.title = Titles.home
        nc2.title = Titles.doctors
        nc3.title = Titles.chat
        nc4.title = Titles.drugs
        nc5.title = Titles.profile
    }
    
    private func setTabBarItemImages() {
        nc1.tabBarItem.image = SFSymbols.home
        nc2.tabBarItem.image = SFSymbols.doctors
        nc3.tabBarItem.image = SFSymbols.chat
        nc4.tabBarItem.image = SFSymbols.drug
        nc5.tabBarItem.image = SFSymbols.profile
    }
    
}

