//
//  UserInfoAPI.swift
//  Curify
//
//

import UIKit
import Alamofire

extension API {
    func fillUserInfo(model: UserModel, completion: @escaping (Result<String, Error>) -> Void) {
        let url = API_URL_FILL_USER_INFO
        
        let parameters: [String: Any] = [
            "name": model.name,
            "weigh": model.weight,
            "height": model.height,
            "age": model.age,
            "waist": model.waist
        ]
        
        AF.request(url, method: .post, parameters: parameters, encoding: JSONEncoding.default, interceptor: nil)
            .response { resp in
                switch resp.result {
                case .success(_):
                    completion(.success("Success"))
                case .failure(let error):
                    completion(.failure(error))
                }
            }
    }
    
    func showUserInfo(model: UserModel, completion: @escaping (Result<UserModel, Error>) -> Void) {
        let url = API_URL_SHOW_USER_INFO
//        let headers = Token.getToken()
        
        AF.request(url, method: .post, parameters: nil, encoding: URLEncoding.default, interceptor: nil)
            .response { resp in
                switch resp.result {
                case .success(let data):
                    do {
                        let decoder = JSONDecoder()
                        let data = try decoder.decode(UserModel.self, from: data!)
                        completion(.success(data))
                    } catch {
                        completion(.failure(error))
                    }
                case .failure(let error):
                    completion(.failure(error))
                }
            }
    }
}
