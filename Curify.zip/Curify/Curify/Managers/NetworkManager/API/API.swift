//
//  API.swift
//  Curify
//
//

import UIKit
import Alamofire

let BASE_URL = "https://open-data.up.railway.app/api/v1/"

class API {
    static let shared = API()
    
    // Login
    
    let API_URL_LOGIN = BASE_URL + "inner/login"
    let API_URL_SIGN_UP = BASE_URL + "inner/signup"
    let API_URL_DELETE_ACCOUNT = BASE_URL + "inner/dashboard/middle/deleteAccount"
    
    // News
    
    let API_URL_GET_NEWS = BASE_URL + "news/getall?page="
    
    
    // UserInfo
    
    let API_URL_FILL_USER_INFO = BASE_URL + "dashboard/fillUserInfo"
    let API_URL_SHOW_USER_INFO = BASE_URL + "dashboard/middle/showUserInfo"
    
    // Drug
    
    let API_URL_DRUG_SEARCH = BASE_URL + "inner/dashboard/searchDrug?name="
    let API_URL_GET_DRUG_TYPES = BASE_URL + "inner/dashboard/getalltype"
    
    // Chat
    
    let API_URL_GET_ALL_MESSAGES = BASE_URL + "inner/dashboard/middle/get-all-messages"
    let API_URL_SEND_REQUEST = BASE_URL + "inner/dashboard/middle/send-request"
    
    // Doctor
    
    let API_URL_GET_ALL_DOCTORS = BASE_URL + "doc/getalldoctors"
    let API_URL_SCHEDULE_APPPOINTMENT = BASE_URL + "schedule/create"
    let API_URL_SEARCH_DOCTOR = BASE_URL + "doc/getonedoctor?name="
}

class Token {
    static func getToken() -> HTTPHeaders {
        let headers: HTTPHeaders = [
            "Cookie": "mysession=\(UD.token ?? "")"
        ]
        return headers
    }
}

