//
//  DrugAPI.swift
//  Curify
//
//

import UIKit
import Alamofire

extension API {
    func getDrugTypes(completion: @escaping (Result<[DrugTypeModel], Error>) -> Void) {
        let url = API_URL_GET_DRUG_TYPES
        let headers = Token.getToken()
        
        AF.request(url, method: .get, parameters: nil, encoding: URLEncoding.default, headers: headers, interceptor: nil)
            .response { resp in
                switch resp.result {
                case .success(let data):
                    do {
                        let decoder = JSONDecoder()
                        let data = try decoder.decode([DrugTypeModel].self, from: data!)
                        completion(.success(data))
                    } catch {
                        completion(.failure(error))
                    }
                case .failure(let error):
                    completion(.failure(error))
                }
            }
    }
    
    func searchDrug(query: String, completion: @escaping (Result<[DrugModel], Error>) -> Void) {
        let url = API_URL_DRUG_SEARCH + query
        let parameters: [String: String] = [
            "name": query
        ]
        
        let headers = Token.getToken()
        
        AF.request(url, method: .get, parameters: parameters, encoding: URLEncoding.default, headers: headers, interceptor: nil)
            .response { resp in
                switch resp.result {
                case .success(let data):
                    do {
                        let decoder = JSONDecoder()
                        let data = try decoder.decode([DrugModel].self, from: data!)
                        completion(.success(data))
                    } catch {
                        completion(.failure(error))
                    }
                case .failure(let error):
                    completion(.failure(error))
                }
            }
    }
}
