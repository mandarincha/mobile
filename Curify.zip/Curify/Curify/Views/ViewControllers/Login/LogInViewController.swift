//
//  LogInViewController.swift
//  Curify
//
//

import UIKit

protocol LogInViewControllerDelegate: AnyObject {
    func continueButtonPressed()
}

class LogInViewController: BaseViewController {
    
    lazy var subView = SubView(frame: .zero)
    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        tableView.isScrollEnabled = false
        tableView.backgroundColor = .clear
        tableView.showsVerticalScrollIndicator = false
        tableView.register(LogInTableViewCell.self, forCellReuseIdentifier: String(describing: LogInTableViewCell.self))
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configure()
        initViews()
    }
    
    private func initViews() {
        view.addSubview(subView)
        subView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        subView.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    @objc func dismissRegisterViewController() {
        dismiss(animated: true, completion: nil)
    }
}

extension LogInViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: LogInTableViewCell.self), for: indexPath) as? LogInTableViewCell else { return UITableViewCell() }
        cell.delegate = self
        cell.backgroundColor = .clear
        cell.selectionStyle = .none
        return cell
    }
}

extension LogInViewController: LogInViewControllerDelegate {
    func continueButtonPressed() {
        let loginVC = SignInViewController()
        let navigationController = UINavigationController(rootViewController: loginVC)
        navigationController.modalPresentationStyle = .fullScreen
        let backButton = UIBarButtonItem(image: SFSymbols.back, style: .plain, target: self, action: #selector(self.dismissRegisterViewController))
        backButton.tintColor = Colors.label
        loginVC.navigationItem.leftBarButtonItem = backButton
        self.present(navigationController, animated: true, completion: nil)
    }
}

