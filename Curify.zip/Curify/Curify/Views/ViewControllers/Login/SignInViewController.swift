//
//  SignInViewController.swift
//  Curify
//
//

import UIKit

protocol SignInViewControllerDelegate: AnyObject {
    func signInButtonPressed(email: String?, password: String?)
    func signUpButtonPressed(email: String?, password: String?)
}

class SignInViewController: BaseViewController {
    
    lazy var subView = SubView(frame: .zero)
    
    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        tableView.backgroundColor = .clear
        tableView.showsVerticalScrollIndicator = false
        tableView.register(SignInTableViewCell.self, forCellReuseIdentifier: String(describing: SignInTableViewCell.self))
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configure()
        initViews()
        hideKeyboardWhenTappedAround()
    }
    
    private func initViews() {
        view.addSubview(subView)
        subView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        subView.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
}

extension SignInViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: SignInTableViewCell.self), for: indexPath) as? SignInTableViewCell else { return UITableViewCell() }
        cell.delegate = self
        cell.backgroundColor = .clear
        cell.selectionStyle = .none
        return cell
    }
}

extension SignInViewController: SignInViewControllerDelegate {
    func signInButtonPressed(email: String?, password: String?) {
        if let email = email, email.replacingOccurrences(of: " ", with: "") != "", let password = password, password.replacingOccurrences(of: " ", with: "") != "" {
            showLoadingView()
            API.shared.login(email: email, password: password) { [weak self] result in
                switch result {
                case .success(let data):
                    UD.token = data.access_token
                    UD.email = email
                    self?.dissmissLoadingView()
                    self?.setNewRootViewController()
                case.failure(let error):
                    print(error.localizedDescription)
                    self?.dissmissLoadingView()
                    self?.showAlert(title: "Error", message: Alerts.loginFailed)
                }
            }
        }
    }
    
    func signUpButtonPressed(email: String?, password: String?) {
        if let password = password?.replacingOccurrences(of: " ", with: "") {
            if password.count < 6 {
                showAlert(title: "Error", message: Alerts.invalidPassword)
                return
            }
        }
        
        if let email = email?.replacingOccurrences(of: " ", with: "") {
            if !isValidEmail(email) {
                showAlert(title: "Error", message: Alerts.invalidEmail)
                return
            }
        }
        
        if let email = email, let password = password {
            self.showLoadingView()
            API.shared.signUp(email: email, password: password) { [weak self] result in
                switch result {
                case .success(_):
                    API.shared.login(email: email, password: password) { [weak self] result in
                        switch result {
                        case .success(let data):
                            UD.token = data.access_token
                            UD.email = email
                            self?.dissmissLoadingView()
                            self?.setNewRootViewController()
                        case.failure(let error):
                            print(error.localizedDescription)
                            self?.dissmissLoadingView()
                            self?.showAlert(title: "Error", message: Alerts.wentWrong)
                        }
                    }
                case .failure(_):
                    self?.dissmissLoadingView()
                    self?.showAlert(title: "Error", message: Alerts.signUpFailure)
                }
                self?.dissmissLoadingView()
            }
        }
    }
}
