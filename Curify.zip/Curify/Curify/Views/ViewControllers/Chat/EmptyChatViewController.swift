//
//  EmptyChatViewController.swift
//  Curify
//
//

import UIKit

protocol EmptyChatViewControllerDelegate: AnyObject {
    func startButtonPressed()
}

class EmptyChatViewController: BaseViewController {
    lazy var subView = SubView(frame: .zero)
    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.backgroundColor = .clear
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        tableView.showsVerticalScrollIndicator = false
        tableView.register(EmptyChatTableViewCell.self, forCellReuseIdentifier: String(describing: EmptyChatTableViewCell.self))
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configure()
        initViews()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.prefersLargeTitles = true
        DispatchQueue.main.async { [weak self] in
            self?.navigationController?.navigationBar.sizeToFit()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.navigationBar.prefersLargeTitles = false
    }
    
    private func initViews() {
        title = "Chat"
        view.addSubview(subView)
        subView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        subView.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    @objc func dismissViewController() {
        self.dismiss(animated: true)
    }
}

extension EmptyChatViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: EmptyChatTableViewCell.self), for: indexPath) as? EmptyChatTableViewCell else { return UITableViewCell() }
        cell.backgroundColor = .clear
        cell.selectionStyle = .none
        cell.delegate = self
        return cell
    }
}

extension EmptyChatViewController: EmptyChatViewControllerDelegate {
    func startButtonPressed() {
        let vc = SearchDoctorViewController()
//        let navigationController = UINavigationController(rootViewController: chatVC)
//        navigationController.modalPresentationStyle = .fullScreen
//        let backButton = UIBarButtonItem(image: SFSymbols.back, style: .plain, target: self, action: #selector(self.dismissViewController))
//        backButton.tintColor = Colors.label
//        chatVC.navigationItem.leftBarButtonItem = backButton
        navigationController?.pushViewController(vc, animated: true)
    }
}
