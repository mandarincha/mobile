//
//  SearchDoctorViewController.swift
//  Curify
//
//

import UIKit

class SearchDoctorViewController: BaseViewController {
    
    lazy var subView = SubView(frame: .zero)
    
    lazy var searchController: UISearchController = {
        let searchController = UISearchController(searchResultsController: AllDrugsViewController())
        searchController.searchBar.placeholder = "Search for a doctor"
        searchController.searchBar.searchBarStyle = .minimal
        return searchController
    }()
    
    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        tableView.showsVerticalScrollIndicator = false
        tableView.backgroundColor = .clear
        tableView.register(AllDoctorsTableViewCell.self, forCellReuseIdentifier: String(describing: AllDoctorsTableViewCell.self))
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configure()
        initViews()
        hideKeyboardWhenTappedAround()
    }
    
    private func initViews() {
        title = "Search"
        
        view.addSubview(subView)
        subView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        
    }
    
    @objc func dismissViewController() {
        self.dismiss(animated: true)
    }
}

extension SearchDoctorViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: AllDoctorsTableViewCell.self), for: indexPath) as? AllDoctorsTableViewCell else { return UITableViewCell() }
        cell.backgroundColor = .clear
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let chatVC = ChatPageViewController()
        let navigationController = UINavigationController(rootViewController: chatVC)
        navigationController.modalPresentationStyle = .fullScreen
        let backButton = UIBarButtonItem(image: SFSymbols.back, style: .plain, target: self, action: #selector(self.dismissViewController))
        backButton.tintColor = Colors.label
        chatVC.navigationItem.leftBarButtonItem = backButton
        self.present(navigationController, animated: true, completion: nil)
    }
}
