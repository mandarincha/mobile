//
//  HistoryViewController.swift
//  Curify
//
//

import UIKit
import Charts

class HistoryViewController: BaseViewController {
    
    override func viewDidLoad() {
        
    }
}
