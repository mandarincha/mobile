//
//  DrugsCollectionViewCell.swift
//  Curify
//
//

import UIKit

class DrugsCollectionViewCell: UICollectionViewCell {
    
    lazy var subView = SubView(frame: .zero)
    
    lazy var imageView: MainImageView = {
        let imageView = MainImageView(frame: .zero)
        imageView.layer.cornerRadius = 12
        return imageView
    }()
    
    lazy var nameLabel: Label = {
        let label = Label(font: .systemFont(ofSize: 17, weight: .medium))
        label.textAlignment = .center
        label.lineBreakMode = .byTruncatingTail
        label.numberOfLines = 1
        label.text = ""
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func initViews() {
        self.backgroundColor = .clear
        contentView.addSubview(subView)
        subView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        subView.addSubview(imageView)
        imageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview().offset(10)
            make.trailing.equalToSuperview().offset(-10)
            make.height.equalTo(130)
        }
        
        subView.addSubview(nameLabel)
        nameLabel.snp.makeConstraints { make in
            make.top.equalTo(imageView.snp.bottom).offset(5)
            make.leading.trailing.equalTo(imageView)
            make.bottom.equalToSuperview().offset(-10)
        }
    }
    
    func setData(model: DrugModel) {
        nameLabel.text = model.name
        imageView.loadImage(with: model.photo?[0])
    }
}
