//
//  LogInTableViewCell.swift
//  Curify
//
//

import UIKit

class LogInTableViewCell: UITableViewCell {

    lazy var subView = SubView(frame: .zero)
    lazy var continueButton = Button(title: "Continue with email")
    weak var delegate: LogInViewControllerDelegate?
    
    lazy var nameLabel: Label = {
        let label = Label(font: .systemFont(ofSize: 36, weight: .bold))
        label.textColor = Colors.label
        return label
    }()
    
    lazy var joinLabel: Label = {
        let label = Label(font: .systemFont(ofSize: 20, weight: .regular))
        label.text = "Stay med-savvy with Curify"
        label.textColor = .systemGray
        label.textAlignment = .center
        return label
    }()
    
    lazy var mainImageView: ImageView = {
        let imageView = ImageView (frame: .zero)
        imageView.contentMode = .scaleAspectFill
        imageView.image = Images.mainImage0
        imageView.layer.cornerRadius = 10
        return imageView
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        initViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func continueButtonPressed() {
        delegate?.continueButtonPressed()
    }
    
    private func initViews() {
        contentView.addSubview(subView)
        subView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        subView.addSubview(mainImageView)
        mainImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(200)
            make.leading.equalToSuperview().offset(10)
            make.trailing.equalToSuperview().offset(-10)
            make.height.equalTo(250)
        }
        
        subView.addSubview(nameLabel)
        nameLabel.text = "C u r i f y"
        nameLabel.snp.makeConstraints { make in
            make.top.equalTo(mainImageView.snp.bottom).offset(25)
            make.centerX.equalToSuperview()
        }
        
        subView.addSubview(joinLabel)
        joinLabel.snp.makeConstraints { make in
            make.top.equalTo(nameLabel.snp.bottom).offset(20)
            make.leading.equalToSuperview().offset(15)
            make.trailing.equalToSuperview().offset(-15)
        }
        
        subView.addSubview(continueButton)
        continueButton.addTarget(self, action: #selector(continueButtonPressed), for: .touchUpInside)
        continueButton.snp.makeConstraints { make in
            make.top.equalTo(joinLabel.snp.bottom).offset(60)
            make.leading.equalToSuperview().offset(25)
            make.trailing.equalToSuperview().offset(-25)
            make.height.equalTo(50)
            make.bottom.equalToSuperview()
        }
    }
}
