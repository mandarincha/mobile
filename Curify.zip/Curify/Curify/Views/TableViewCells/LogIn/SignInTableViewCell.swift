//
//  SignInTableViewCell.swift
//  Curify
//
//

import UIKit

class SignInTableViewCell: UITableViewCell {

    lazy var subView = SubView(frame: .zero)
    lazy var titleLabel = Label(font: .systemFont(ofSize: 24, weight: .bold))
    lazy var emailLabel = Label(font: .systemFont(ofSize: 17, weight: .medium))
    lazy var passwordLabel = Label(font: .systemFont(ofSize: 17, weight: .medium))
    lazy var emailTextField = TextField(font: .systemFont(ofSize: 20, weight: .regular))
    lazy var passwordTextField = TextField(font: .systemFont(ofSize: 20, weight: .regular))
    lazy var signInButton = Button(title: "Sign in")
    lazy var signUpButton = Button(title: "Sign up")
    weak var delegate: SignInViewControllerDelegate?
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        initViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func signInButtonPressed() {
        guard let email = emailTextField.text, let password = passwordTextField.text else { return }
        delegate?.signInButtonPressed(email: email, password: password)
    }
    
    @objc func signUpButtonPressed() {
        guard let email = emailTextField.text, let password = passwordTextField.text else { return }
        delegate?.signUpButtonPressed(email: email, password: password)
    }
    
    private func initViews() {
        contentView.addSubview(subView)
        subView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        subView.addSubview(titleLabel)
        titleLabel.text = "Welcome"
        titleLabel.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview().offset(20)
        }
        
        subView.addSubview(emailLabel)
        emailLabel.text = "Email adress"
        emailLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(60)
            make.leading.equalTo(titleLabel)
        }
        
        subView.addSubview(emailTextField)
        emailTextField.placeholder = "Enter email adress"
        emailTextField.layer.cornerRadius = 6
        emailTextField.snp.makeConstraints { make in
            make.top.equalTo(emailLabel.snp.bottom).offset(5)
            make.leading.equalTo(emailLabel)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(50)
        }
        
        subView.addSubview(passwordLabel)
        passwordLabel.text = "Password"
        passwordLabel.snp.makeConstraints { make in
            make.top.equalTo(emailTextField.snp.bottom).offset(30)
            make.leading.equalTo(emailLabel)
        }
        
        subView.addSubview(passwordTextField)
        passwordTextField.placeholder = "Enter password"
        passwordTextField.isSecureTextEntry = true
        passwordTextField.layer.cornerRadius = 6
        passwordTextField.snp.makeConstraints { make in
            make.top.equalTo(passwordLabel.snp.bottom).offset(5)
            make.leading.equalTo(passwordLabel)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(50)
        }
        
        subView.addSubview(signInButton)
        signInButton.addTarget(self, action: #selector(signInButtonPressed), for: .touchUpInside)
        signInButton.snp.makeConstraints { make in
            make.top.equalTo(passwordTextField.snp.bottom).offset(50)
            make.leading.trailing.equalTo(passwordTextField)
            make.height.equalTo(50)
        }
        
        subView.addSubview(signUpButton)
        signUpButton.addTarget(self, action: #selector(signUpButtonPressed), for: .touchUpInside)
        signUpButton.snp.makeConstraints { make in
            make.top.equalTo(signInButton.snp.bottom).offset(10)
            make.leading.trailing.equalTo(signInButton)
            make.height.equalTo(50)
            make.bottom.equalToSuperview()
        }
    }
}
