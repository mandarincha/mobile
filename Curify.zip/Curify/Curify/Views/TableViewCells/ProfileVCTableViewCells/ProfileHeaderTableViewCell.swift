//
//  ProfileHeaderTableViewCell.swift
//  Curify
//
//

import UIKit

class ProfileHeaderTableViewCell: UITableViewCell {

    lazy var subView = SubView(frame: .zero)
    lazy var avatarImageView = ImageView(frame: .zero)
    lazy var nameLabel = Label(font: .systemFont(ofSize: 24, weight: .semibold))
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        initViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func initViews() {
        self.backgroundColor = .clear
        self.selectionStyle = .none
        contentView.addSubview(subView)
        subView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        subView.addSubview(avatarImageView)
        avatarImageView.layer.cornerRadius = 40
        avatarImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.centerX.equalToSuperview()
            make.height.width.equalTo(80)
        }
        
        subView.addSubview(nameLabel)
        nameLabel.text = "Username"
        nameLabel.snp.makeConstraints { make in
            make.top.equalTo(avatarImageView.snp.bottom).offset(10)
            make.centerX.equalToSuperview()
            make.bottom.equalToSuperview().offset(-50)
        }
    }
    
    func setData(name: String) {
        avatarImageView.image = SFSymbols.avatar
        nameLabel.text = name
    }
}
