//
//  ChatReceiverTableViewCell.swift
//  Curify
//
//

import UIKit

class ChatReceiverTableViewCell: UITableViewCell {

    lazy var subView = SubView(frame: .zero)
    lazy var contentLabel: Label = {
        let label = Label(font: .systemFont(ofSize: 17, weight: .regular))
        label.textColor = .label
        return label
    }()
    
    lazy var containerView: SubView = {
        let view = SubView(frame: .zero)
        view.layer.cornerRadius = 16
        view.backgroundColor = .systemGray6
        view.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMaxYCorner, .layerMaxXMinYCorner]
        return view
    }()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        initView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setData(text: String) {
        contentLabel.text = text
    }
    
    private func initView() {
        self.selectionStyle = .none
        self.backgroundColor = .clear
        self.addSubview(subView)
        subView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        subView.addSubview(containerView)
        containerView.addSubview(contentLabel)
        containerView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(5)
            make.bottom.equalToSuperview().offset(-5)
            make.leading.equalToSuperview().offset(15)
            make.trailing.equalToSuperview().offset(-UIScreen.main.bounds.width / 4)
        }
        
        containerView.addSubview(contentLabel)
        contentLabel.snp.makeConstraints { make in
            make.leading.top.equalToSuperview().offset(10)
            make.trailing.bottom.equalToSuperview().offset(-10)
        }
    }

}
