//
//  EmptyChatTableViewCell.swift
//  Curify
//
//

import UIKit

class EmptyChatTableViewCell: UITableViewCell {

    lazy var subView = SubView(frame: .zero)
    lazy var label2 = Label(font: .systemFont(ofSize: 17, weight: .medium))
    lazy var startButton = Button(title: "Start a new chat")
    weak var delegate: EmptyChatViewControllerDelegate?
    
    lazy var label1: Label = {
        let label = Label(font: .systemFont(ofSize: 20, weight: .bold))
        label.textColor = Colors.label
        return label
    }()
    lazy var emptyChatImageView: ImageView = {
        let imageView = ImageView(frame: .zero)
        imageView.image = SFSymbols.emptyChat
        return imageView
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        initViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func startButtonPressed() {
        delegate?.startButtonPressed()
    }
    
    private func initViews() {
        contentView.addSubview(subView)
        subView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        subView.addSubview(emptyChatImageView)
        emptyChatImageView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(50)
            make.height.equalTo(40)
            make.width.equalTo(60)
        }
        
        subView.addSubview(label1)
        label1.text = "No chats so far"
        label1.snp.makeConstraints { make in
            make.top.equalTo(emptyChatImageView.snp.bottom).offset(40)
            make.centerX.equalToSuperview()
        }
        
        subView.addSubview(label2)
        label2.text = Texts.emptyChat
        label2.textColor = .systemGray
        label2.textAlignment = .center
        label2.snp.makeConstraints { make in
            make.top.equalTo(label1.snp.bottom).offset(30)
            make.leading.equalToSuperview().offset(40)
            make.trailing.equalToSuperview().offset(-40)
        }
        
        subView.addSubview(startButton)
        startButton.addTarget(self, action: #selector(startButtonPressed), for: .touchUpInside)
        startButton.snp.makeConstraints { make in
            make.top.equalTo(label2.snp.bottom).offset(230)
            make.leading.equalToSuperview().offset(25)
            make.trailing.equalToSuperview().offset(-25)
            make.height.equalTo(50)
            make.bottom.equalToSuperview()
        }
    }

}
