//
//  DrugDetailsTableViewCell.swift
//  Curify
//
//

import UIKit

class DrugDetailsTableViewCell: UITableViewCell {
    
    let width = UIScreen.main.bounds.width
    lazy var subView = SubView(frame: .zero)
    lazy var nameLabel = Label(font: .systemFont(ofSize: 24, weight: .bold))
    lazy var manufacturerLabel = Label(font: .systemFont(ofSize: 20, weight: .semibold))
    lazy var descriptionLabel = Label(font: .systemFont(ofSize: 17, weight: .regular))
    lazy var receiptLabel = Label(font: .systemFont(ofSize: 20, weight: .semibold))
    lazy var receipt = Label(font: .systemFont(ofSize: 17, weight: .regular))
    lazy var manufacturerName: Label = {
        let label = Label(font: .systemFont(ofSize: 20, weight: .medium))
        label.numberOfLines = 1
        label.lineBreakMode = .byTruncatingTail
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        initViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func initViews() {
        self.backgroundColor = .clear
        self.selectionStyle = .none
        contentView.addSubview(subView)
        subView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        subView.addSubview(nameLabel)
        nameLabel.snp.makeConstraints { make in
            make.top.leading.equalToSuperview().offset(15)
            make.trailing.equalToSuperview().offset(-15)
        }
        
        subView.addSubview(manufacturerLabel)
        manufacturerLabel.snp.makeConstraints { make in
            make.top.equalTo(nameLabel.snp.bottom).offset(10)
            make.leading.equalTo(nameLabel)
            make.width.equalTo(135)
        }
        
        subView.addSubview(manufacturerName)
        manufacturerName.snp.makeConstraints { make in
            make.centerY.equalTo(manufacturerLabel)
            make.leading.equalTo(manufacturerLabel.snp.trailing).offset(10)
            make.trailing.equalTo(nameLabel)
        }
        
        subView.addSubview(descriptionLabel)
        descriptionLabel.snp.makeConstraints { make in
            make.top.equalTo(manufacturerLabel.snp.bottom).offset(15)
            make.leading.trailing.equalTo(nameLabel)
        }
        
        subView.addSubview(receiptLabel)
        receiptLabel.snp.makeConstraints { make in
            make.top.equalTo(descriptionLabel.snp.bottom).offset(10)
            make.leading.equalTo(manufacturerLabel)
        }
        
        subView.addSubview(receipt)
        receipt.snp.makeConstraints { make in
            make.top.equalTo(receiptLabel.snp.bottom).offset(10)
            make.leading.trailing.equalTo(descriptionLabel)
            make.bottom.equalToSuperview()
        }
    }
    
    func setData(model: DrugModel) {
        nameLabel.text = model.name
        manufacturerLabel.text = "Manufacturer:"
        manufacturerName.text = model.manufacturer
        descriptionLabel.text = model.description
        receiptLabel.text = "Receipt"
        receipt.text = model.receipt
    }
}
