//
//  AllDrugsTableViewCell.swift
//  Curify
//
//  Created by Uyg'un Tursunov on 26/01/24.
//

import UIKit

class AllDrugsTableViewCell: UITableViewCell {

    lazy var subView = SubView(frame: .zero)
    lazy var mainImageView = MainImageView(frame: .zero)
    lazy var nameLabel: Label = {
        let label = Label(font: .systemFont(ofSize: 17, weight: .medium))
        label.numberOfLines = 1
        label.lineBreakMode = .byTruncatingTail
        return label
    }()
    
    lazy var manufacturerLabel: Label = {
        let label = Label(font: .systemFont(ofSize: 17, weight: .regular))
        label.numberOfLines = 1
        label.lineBreakMode = .byTruncatingTail
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        initViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func initViews() {
        backgroundColor = .clear
        selectionStyle = .none
        
        contentView.addSubview(subView)
        subView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        subView.addSubview(mainImageView)
        mainImageView.snp.makeConstraints { make in
            make.leading.equalToSuperview().offset(15)
            make.top.equalToSuperview().offset(5)
            make.bottom.equalToSuperview().offset(-5)
            make.height.equalTo(90)
            make.width.equalTo(100)
        }
        
        subView.addSubview(nameLabel)
        nameLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview().offset(-10)
            make.leading.equalTo(mainImageView.snp.trailing).offset(10)
            make.trailing.equalToSuperview().offset(-20)
        }
        
        subView.addSubview(manufacturerLabel)
        manufacturerLabel.snp.makeConstraints { make in
            make.leading.equalTo(nameLabel)
            make.centerY.equalToSuperview().offset(10)
            make.trailing.equalTo(nameLabel)
        }
    }
    
    func setData(model: DrugModel) {
        mainImageView.loadImage(with: model.photo?[0])
        nameLabel.text = model.name
        manufacturerLabel.text = model.manufacturer
    }
}
