//
//  ProfileViewController.swift
//  Curify
//
//

import UIKit
import StoreKit

class ProfileViewController: BaseViewController {
    
    let menuOptions = ["Personal info", "Rate app", "Terms of use", "Info about app",  "Sign out"]
    let menuIcons = [SFSymbols.profile, SFSymbols.star, SFSymbols.question, SFSymbols.about,  SFSymbols.logOut]
    
    lazy var subView = SubView(frame: .zero)
    
    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .clear
        tableView.register(ProfileMenusTableViewCell.self, forCellReuseIdentifier: String(describing: ProfileMenusTableViewCell.self))
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configure()
        initViews()
    }
    
    @objc func dismissViewController() {
        dismiss(animated: true)
    }
    
    private func initViews() {
        navigationController?.navigationBar.prefersLargeTitles = true
        title = "Profile"
        
        view.addSubview(subView)
        subView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        subView.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
}

extension ProfileViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: ProfileMenusTableViewCell.self), for: indexPath) as? ProfileMenusTableViewCell else { return UITableViewCell() }
        cell.setData(title: menuOptions[indexPath.row], image: menuIcons[indexPath.row]!)
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        var vc: UIViewController?
        
        switch indexPath.row {
        case 0:
            vc = HealthDetailsViewController()
        case 1:
            if #available(iOS 10.3, *) {
                SKStoreReviewController.requestReview()
            } else if let url = URL(string: "itms-apps://itunes.apple.com/app/" + "appId") {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            }
        case 2:
            vc = InfoViewController()
        case 3:
            vc = InfoViewController()
        case 4:
            let alertController = UIAlertController(title: "Sign out", message: Alerts.signOut, preferredStyle: .alert)
            let logoutAction = UIAlertAction(title: "Sign out", style: .destructive) { (action) in
                UD.token = ""
                UD.email = ""
                self.goSigninPage()
            }
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
            alertController.addAction(logoutAction)
            alertController.addAction(cancelAction)
            present(alertController, animated: true, completion: nil)
        default:
            break
        }
        
        guard let vc = vc else { return }
        let navigationController = UINavigationController(rootViewController: vc)
        let backButton = UIBarButtonItem(image: SFSymbols.back, style: .plain, target: self, action: #selector(dismissViewController))
        backButton.tintColor = Colors.label
        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(dismissViewController))
        doneButton.tintColor = Colors.label
        vc.navigationItem.leftBarButtonItem = backButton
        //        vc.navigationItem.rightBarButtonItem = doneButton
        self.present(navigationController, animated: true, completion: nil)
    }
}
