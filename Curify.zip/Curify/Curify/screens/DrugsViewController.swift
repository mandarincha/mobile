//
//  DrugsViewController.swift
//  Curify
//
//

import UIKit

protocol DrugsViewControllerDelegate: AnyObject {
    func didSelectDrug(model: DrugModel)
    func allButtonPressed(section: Int)
}

class DrugsViewController: BaseViewController {
    
    var drugTypes = [DrugTypeModel]() {
        didSet {
            tableView.reloadData()
        }
    }
    
    lazy var subView = SubView(frame: .zero)
    var loadedSuccessfully: Bool = false
    
    lazy var searchController: UISearchController = {
        let searchController = UISearchController(searchResultsController: AllDrugsViewController())
        searchController.searchBar.placeholder = "Search for a drug"
        searchController.searchBar.searchBarStyle = .minimal
        return searchController
    }()
    
    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        tableView.backgroundColor = .clear
        tableView.showsVerticalScrollIndicator = false
        tableView.register(DrugsTableViewCell.self, forCellReuseIdentifier: String(describing: DrugsTableViewCell.self))
        tableView.contentInset = UIEdgeInsets(top: 20, left: 0, bottom: 0, right: 0)
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configure()
        initViews()
        getDrugs()
    }
    
    func getDrugs() {
        showLoadingView()
        API.shared.getDrugTypes() { [weak self] result in
            self?.dissmissLoadingView()
            switch result {
            case .success(let data):
                self?.drugTypes = data
                self?.tableView.reloadData()
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    private func initViews() {
        navigationController?.navigationBar.prefersLargeTitles = true
        title = "Drugs"
        
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false
        searchController.searchResultsUpdater = self
        
        definesPresentationContext = true
        
        view.addSubview(subView)
        subView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        subView.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    @objc func dismissViewController() {
        dismiss(animated: true)
    }
}

extension DrugsViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return drugTypes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: DrugsTableViewCell.self), for: indexPath) as? DrugsTableViewCell else { return UITableViewCell() }
        cell.delegate = self
        if let drugs = drugTypes[indexPath.section].Drugs {
            cell.drugs = drugs
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let sectionHeaderView = SectionHeaderView(frame: .zero)
        sectionHeaderView.isDrug = true
        sectionHeaderView.drugDelegate = self
        if let type = drugTypes[section].type {
            sectionHeaderView.section = section
            sectionHeaderView.setData(title: type)
        }
        return sectionHeaderView
    }
}

extension DrugsViewController: UISearchResultsUpdating, UISearchBarDelegate {
    func updateSearchResults(for searchController: UISearchController) {
        let searchBar = searchController.searchBar
        guard let query = searchBar.text, !query.isEmpty,
              let resultsController = searchController.searchResultsController as? AllDrugsViewController else { return }
//        showLoadingView()
        API.shared.searchDrug(query: query) { [weak self] result in
            switch result {
            case .success(let data):
                self?.loadedSuccessfully = true
                resultsController.drugs = data
                DispatchQueue.main.async {
                    resultsController.tableView.reloadData()
                }
            case .failure(let error):
                self?.loadedSuccessfully = false
                resultsController.drugs = []
                print(error.localizedDescription)
            }
        }
    }
}

extension DrugsViewController: DrugsViewControllerDelegate {
    func didSelectDrug(model: DrugModel) {
        let vc = DrugDetailsViewController()
        vc.title = model.name
        vc.drugModel = model
        let navigationController = UINavigationController(rootViewController: vc)
        navigationController.navigationBar.prefersLargeTitles = false
        navigationController.modalPresentationStyle = .fullScreen
        let backButton = UIBarButtonItem(image: SFSymbols.back, style: .plain, target: self, action: #selector(dismissViewController))
        backButton.tintColor = Colors.label
        vc.navigationItem.leftBarButtonItem = backButton
        self.present(navigationController, animated: true, completion: nil)
    }
    
    func allButtonPressed(section: Int) {
        let vc = AllDrugsViewController()
        if let drugs = drugTypes[section].Drugs, let type = drugTypes[section].type {
            vc.title = type
            vc.drugs = drugs
        }
        navigationController?.pushViewController(vc, animated: true)
    }
}
