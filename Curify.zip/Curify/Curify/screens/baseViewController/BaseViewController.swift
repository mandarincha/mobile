//
//  BaseViewController.swift
//  Curify
//
//

import UIKit
import SnapKit

class BaseViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configure()
    }
    
    func configure() {
        view.backgroundColor = .systemBackground
        
        if let navigationBar = navigationController?.navigationBar {
            navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: Colors.label]
            navigationBar.largeTitleTextAttributes = [NSAttributedString.Key.foregroundColor: Colors.label]
            navigationBar.tintColor = Colors.label
        }
        
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }
}
