//
//  DrugModel.swift
//  Curify
//
//

import UIKit

struct DrugTypeModel: Codable {
    let id: String
    let type: String?
    let Drugs: [DrugModel]?
}

struct DrugModel: Codable {
    let id: String
    let name: String?
    let manufacturer: String?
    let description: String?
    let receipt: String?
    let photo: [String]?
}
