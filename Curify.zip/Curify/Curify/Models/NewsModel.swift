//
//  NewsModel.swift
//  Curify
//
//

import UIKit

struct NewsModel: Codable {
    let totat_count: Int?
    let total_pages: Int?
    let page: Int?
    let size: Int?
    let has_more: Bool?
    let News: [News]?
}

struct News: Codable {
    let id: String?
    let title: String?
    let body: String?
    let owner: String?
    let photo: String?
    let created_at: String?
}
