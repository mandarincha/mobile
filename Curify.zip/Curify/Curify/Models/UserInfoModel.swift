//
//  UserInfoModel.swift
//  Curify
//
//

import UIKit

class UserInfoModel: Codable {
    static var Id: Int?
    static var name: String?
    static var age: Int?
    static var sex: String?
    static var height: String?
    static var weight: String?
    static var waist: String?
}
