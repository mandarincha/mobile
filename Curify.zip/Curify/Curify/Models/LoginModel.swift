//
//  LoginModel.swift
//  Curify
//
//

import UIKit

struct LoginModel: Codable {
    let access_token: String
}
