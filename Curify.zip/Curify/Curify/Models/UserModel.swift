//
//  UserModel.swift
//  Curify
//
//

import UIKit

struct UserModel: Codable {
    let Id: Int
    let name: String
    let age: Int
    let sex: String
    let height: String
    let weight: String
    let waist: String
}
